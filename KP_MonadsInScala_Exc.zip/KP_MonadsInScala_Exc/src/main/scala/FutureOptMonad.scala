
import scala.concurrent.Future

import scala.concurrent.ExecutionContext.Implicits.global

case class FutureOptMonad[A](value: Future[Option[A]])  {



  def map[B](f: A => B): FutureOptMonad[B] =
    FutureOptMonad(value.map(optA => optA.map(f)))
  def flatMap[B](f: A => FutureOptMonad[B]): FutureOptMonad[B]={
    //Todo: Implement the flatMap method
      null
  }


}





