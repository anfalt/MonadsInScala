

import Model.Customer

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scalaj.http.Http
import play.api.libs.json._


class CustomerService {
  def restEndpoint: String = "https://my-json-server.typicode.com/anfalt/MonadsInScala"

  def requestCustomerByID(customerID:Int): Future[Option[Customer]] = {
   //ToDo: Implement Method

  }


  def jsonObjectToCustomer(json:JsValue): Option[Customer] ={
    try{
      def id = (json \ "id").as[Int]
      def surName = (json \ "SurName").as[String]
      def preName = (json \ "PreName").as[String]
      def age = (json \ "Age").as[Int]
      def postalCode = (json \ "PLZ").as[String]
      Some(new Customer(id,preName,surName,age,postalCode))
    }catch{
      case e =>None
    }


  }


}







