package Model



class Invoice (val id:Int,val CustomerID:Int, val Items:List[Item])
