package Model

class Customer (val id:Int, val PreName:String, val SurName:String, val Age:Int, val PostalCode:String)