package Model


class Item(val Title:String, val Amount:Int, val PricePerUnit:Double, val Currency:String )
