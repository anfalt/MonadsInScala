

import Model.{Invoice, Item}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import scala.util.{Failure, Success}
import scalaj.http.Http
import play.api.libs.json._


  class InvoiceService {
    def restEndpoint: String = "https://my-json-server.typicode.com/anfalt/MonadsInScala"



    def requestAllInvoices(): Future[Option[List[Option[Invoice]]]] = {

      def fa = Future {

        def httpResultInvoices = Http(this.restEndpoint + "/Invoices").asString

        def invoicesAsJSON = Json.parse(httpResultInvoices.body)
        def invoicesJsonList = invoicesAsJSON.as[List[JsValue]]

        def invoicesList =  invoicesJsonList.map(jsonObjectToInvoice)
        Option(invoicesList)

      }
      fa;
    }


    def requestInvoiceByID(id:Int):  Future[Option[Invoice]]  ={
      //ToDo: Implement Method
      def fa = Future {

        def httpResultInvoices = Http(this.restEndpoint + "/Invoices/" + id).asString

        def invoiceAsJSON = Json.parse(httpResultInvoices.body)
        jsonObjectToInvoice(invoiceAsJSON)


      }
      fa;
    }






    def jsonObjectToInvoice(json:JsValue): Option[Invoice] ={
      try {
        def id = (json \ "id").as[Int]

        def customerId = (json \ "CustomerID").as[Int]

        def invoiceItemsJson = (json \ "Items").as[List[JsValue]]

        def invoiceItems = invoiceItemsJson.map(jsonObjectToInvoiceItem)

        def jsonObjectToInvoiceItem(json: JsValue): Item = {
          def title = (json \ "Title").as[String]

          def amount = (json \ "Amount").as[Int]

          def pricePerUnit = (json \ "PricePerUnit").as[Double]

          def currency = (json \ "Currency").as[String]

          new Item(title, amount, pricePerUnit, currency)
        }

       Some(new Invoice(id, customerId, invoiceItems));

      }catch{
        case e=> None
      }
    }


}







