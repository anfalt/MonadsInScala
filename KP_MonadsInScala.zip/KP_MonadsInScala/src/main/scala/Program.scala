


import Model.{Customer, Invoice}

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.Future
import cats.data._
import cats.implicits._



object Program {
  def main(args:Array[String]):Unit = {

  def invoiceService = new InvoiceService();
  def customerService = new CustomerService();

    requestInvoiceCustomerDataWithoutMonad(1)
    requestInvoiceCustomerDataWithMonad(1)
    requestInvoiceCustomerDataWithOptionT(1)

    Thread.sleep(10000)



    def requestInvoiceCustomerDataWithoutMonad(invoiceID:Int): Unit ={
      //Todo: request a customer that belongs to an invoice and print its details by using the printCustomer method.
      // Use flatMap and map, but no Monad
      invoiceService.requestInvoiceByID(invoiceID).flatMap({
        case Some(a:Invoice) => customerService.requestCustomerByID(a.CustomerID).map(_.map(printCustomer))
        case None => Future.successful(None)
      })

    }


    def requestInvoiceCustomerDataWithMonad(invoiceID:Int)= {
//Todo: request a customer that belongs to an invoice and print its details by using the printCustomer method.
      // Use your own FutureOptMonad

      for{
        invoice <- FutureOptMonad(invoiceService.requestInvoiceByID(1))
        customer <- FutureOptMonad(customerService.requestCustomerByID(invoice.CustomerID))
      } yield printCustomer(customer)

      FutureOptMonad(invoiceService.requestInvoiceByID(invoiceID))
        .flatMap((invoice:Invoice)=>FutureOptMonad(customerService.requestCustomerByID(invoice.CustomerID)))
        .map(printCustomer)

    }

    def requestInvoiceCustomerDataWithOptionT(invoiceID:Int)= {
      //Todo: request a customer that belongs to an invoice and print its details by using the printCustomer method.
      // use the OptionT Monad from cats library
          for {
        invoice <- OptionT(invoiceService.requestInvoiceByID(invoiceID))
        customer <- OptionT(customerService.requestCustomerByID(invoice.CustomerID))
      } yield printCustomer(customer)

    }


    def printCustomer(customer:Customer){
      println("CustomerID: " + customer.id)
      println("Name: " + customer.SurName + " " + customer.PreName)
      println("Age: " + customer.Age)
      println("PostalCode: " + customer.PostalCode)
    }
  }
}

